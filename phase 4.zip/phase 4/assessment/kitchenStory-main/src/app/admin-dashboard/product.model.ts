export class ProductModel{
    id:number=0;
    title:string='';
    category:string='';
    price:number=0;
    image:string='';
}