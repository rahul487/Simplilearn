export class AdminModel{
    id:number=0;
    username:string='';
    password:string='';
}