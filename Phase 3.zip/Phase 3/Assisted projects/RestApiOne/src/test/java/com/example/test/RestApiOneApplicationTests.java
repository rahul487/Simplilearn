package com.example.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
